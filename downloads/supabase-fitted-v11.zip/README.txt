Recommended: open APPLY_FITTED_V11.sql as text, copy all contents into a new SQL query at https://supabase.com/dashboard/project/wlxljcobmhjmvnhjlvlk/sql/new and click Run. The complete import, backup and activation are transactional. Do not rerun older migrations 001/003.

If SQL Editor rejects the size, use this smaller three-step fallback instead:
1. Run 01_PREPARE_FALLBACK.sql in SQL Editor.
2. In Table Editor select demo_fitted_v11_import, choose Import data from CSV, and import 02_IMPORT_ROWS.csv (67676 rows). It contains only scalar columns; empty wait cells mean NULL.
3. Run 03_ACTIVATE_FALLBACK.sql in SQL Editor. It refuses activation unless every row and all statistics validate.

VERIFY.sql checks the result. Old public visits/staffing tables are preserved in the private queuecare_before_fitted_v11 schema. Existing month-v5 metadata remains archived by its original dataset ID. Active public visits becomes a view over fitted results; raw waits remain a separate column. Emergency exits live in demo_visit_results. No key is needed in chat. Synthetic demo only. The app server should use SUPABASE_DATASET_ID=fitted-v11 and SUPABASE_MULTI_DATASET_ID=fitted-v11.
